extends Node2D

# =========================================================
# METEOR GAME 2D
# =========================================================

# =========================================================
# SCREEN
# =========================================================

var screen_size: Vector2


# =========================================================
# PLAYER
# =========================================================

var player_pos: Vector2
var player_speed: float = 450.0
var player_size: float = 25.0


# =========================================================
# METEOR
# =========================================================

var meteors: Array = []
var meteor_timer: float = 0.0
var meteor_delay: float = 0.6

var meteor_speed_min: float = 250.0
var meteor_speed_max: float = 500.0


# =========================================================
# GAME
# =========================================================

var score: int = 0
var game_over: bool = false


# =========================================================
# STARS
# =========================================================

const STAR_COUNT: int = 80

var stars: Array = []


# =========================================================
# UI
# =========================================================

var score_label: Label
var game_over_label: Label


# =========================================================
# READY
# =========================================================

func _ready() -> void:

	randomize()

	screen_size = get_viewport_rect().size

	player_pos = Vector2(
		screen_size.x / 2.0,
		screen_size.y - 80.0
	)

	create_ui()
	create_stars()

	queue_redraw()


# =========================================================
# PROCESS
# =========================================================

func _process(delta: float) -> void:

	# -----------------------------------------------------
	# GAME OVER
	# -----------------------------------------------------

	if game_over:

		if Input.is_action_just_pressed("ui_accept"):
			restart_game()

		queue_redraw()

		return


	# -----------------------------------------------------
	# PLAYER CONTROL
	# -----------------------------------------------------

	var direction: float = 0.0

	if Input.is_key_pressed(KEY_A):
		direction -= 1.0

	if Input.is_key_pressed(KEY_D):
		direction += 1.0

	if Input.is_key_pressed(KEY_LEFT):
		direction -= 1.0

	if Input.is_key_pressed(KEY_RIGHT):
		direction += 1.0


	player_pos.x += direction * player_speed * delta


	# Batas kiri dan kanan

	player_pos.x = clamp(
		player_pos.x,
		30.0,
		screen_size.x - 30.0
	)


	# -----------------------------------------------------
	# UPDATE STARS
	# -----------------------------------------------------

	update_stars(delta)


	# -----------------------------------------------------
	# SPAWN METEOR
	# -----------------------------------------------------

	meteor_timer += delta

	if meteor_timer >= meteor_delay:

		meteor_timer = 0.0

		spawn_meteor()


	# -----------------------------------------------------
	# UPDATE METEOR
	# -----------------------------------------------------

	for i in range(meteors.size() - 1, -1, -1):

		var meteor = meteors[i]

		meteor["y"] += meteor["speed"] * delta

		meteors[i] = meteor


		# Meteor keluar layar

		if meteor["y"] > screen_size.y + 80.0:

			meteors.remove_at(i)

			score += 1

			update_score()

			continue


		# Cek tabrakan

		var meteor_position := Vector2(
			meteor["x"],
			meteor["y"]
		)

		if check_collision(
			player_pos,
			meteor_position,
			meteor["size"]
		):

			game_over = true

			show_game_over()


	# -----------------------------------------------------
	# REDRAW
	# -----------------------------------------------------

	queue_redraw()


# =========================================================
# DRAW
# =========================================================

func _draw() -> void:

	# -----------------------------------------------------
	# BACKGROUND
	# -----------------------------------------------------

	draw_rect(
		Rect2(
			Vector2.ZERO,
			screen_size
		),
		Color("#050816")
	)


	# -----------------------------------------------------
	# STARS
	# -----------------------------------------------------

	draw_stars()


	# -----------------------------------------------------
	# METEORS
	# -----------------------------------------------------

	for meteor in meteors:

		var meteor_position := Vector2(
			meteor["x"],
			meteor["y"]
		)

		draw_meteor(
			meteor_position,
			meteor["size"]
		)


	# -----------------------------------------------------
	# PLAYER
	# -----------------------------------------------------

	draw_player()


# =========================================================
# PLAYER
# =========================================================

func draw_player() -> void:

	var points := PackedVector2Array([
		player_pos + Vector2(0.0, -30.0),
		player_pos + Vector2(-25.0, 25.0),
		player_pos + Vector2(0.0, 15.0),
		player_pos + Vector2(25.0, 25.0)
	])


	# Badan pesawat

	draw_colored_polygon(
		points,
		Color("#45e6ff")
	)


	# Api mesin kiri

	draw_circle(
		player_pos + Vector2(-10.0, 27.0),
		6.0,
		Color("#ff9d00")
	)


	# Api mesin kanan

	draw_circle(
		player_pos + Vector2(10.0, 27.0),
		6.0,
		Color("#ff9d00")
	)


	# Lampu tengah

	draw_circle(
		player_pos + Vector2(0.0, -5.0),
		6.0,
		Color.WHITE
	)


# =========================================================
# METEOR
# =========================================================

func draw_meteor(
	pos: Vector2,
	size: float
) -> void:

	var points := PackedVector2Array()

	var sides: int = 8


	for i in range(sides):

		var angle: float = (
			float(i) / float(sides)
		) * TAU

		var radius: float = size

		if i % 2 == 0:
			radius = size * 0.8

		points.append(
			pos + Vector2(
				cos(angle),
				sin(angle)
			) * radius
		)


	# Badan meteor

	draw_colored_polygon(
		points,
		Color("#8b5a3c")
	)


	# Kawah 1

	draw_circle(
		pos + Vector2(
			-size * 0.3,
			-size * 0.2
		),
		size * 0.15,
		Color("#563525")
	)


	# Kawah 2

	draw_circle(
		pos + Vector2(
			size * 0.25,
			size * 0.25
		),
		size * 0.12,
		Color("#563525")
	)


	# Kawah 3

	draw_circle(
		pos + Vector2(
			size * 0.25,
			-size * 0.3
		),
		size * 0.08,
		Color("#563525")
	)


# =========================================================
# SPAWN METEOR
# =========================================================

func spawn_meteor() -> void:

	var meteor := {
		"x": randf_range(
			30.0,
			screen_size.x - 30.0
		),

		"y": -50.0,

		"speed": randf_range(
			meteor_speed_min,
			meteor_speed_max
		),

		"size": randf_range(
			18.0,
			38.0
		)
	}


	meteors.append(meteor)


# =========================================================
# COLLISION
# =========================================================

func check_collision(
	player: Vector2,
	meteor: Vector2,
	meteor_size: float
) -> bool:

	var distance: float = player.distance_to(meteor)

	return distance < (
		player_size + meteor_size
	)


# =========================================================
# CREATE STARS
# =========================================================

func create_stars() -> void:

	stars.clear()


	for i in range(STAR_COUNT):

		var star := {
			"x": randf_range(
				10.0,
				screen_size.x - 10.0
			),

			"y": randf_range(
				0.0,
				screen_size.y
			),

			"size": randf_range(
				1.0,
				3.0
			),

			"speed": randf_range(
				100.0,
				500.0
			)
		}


		stars.append(star)


# =========================================================
# UPDATE STARS
# =========================================================

func update_stars(delta: float) -> void:

	for i in range(stars.size()):

		var star = stars[i]

		star["y"] += star["speed"] * delta


		if star["y"] > screen_size.y:

			star["y"] = 0.0

			star["x"] = randf_range(
				0.0,
				screen_size.x
			)


		stars[i] = star


# =========================================================
# DRAW STARS
# =========================================================

func draw_stars() -> void:

	for star in stars:

		draw_circle(
			Vector2(
				star["x"],
				star["y"]
			),
			star["size"],
			Color.WHITE
		)


# =========================================================
# CREATE UI
# =========================================================

func create_ui() -> void:

	# SCORE

	score_label = Label.new()

	score_label.position = Vector2(
		20.0,
		20.0
	)

	score_label.text = "SCORE: 0"

	score_label.add_theme_font_size_override(
		"font_size",
		28
	)

	add_child(score_label)


	# GAME OVER

	game_over_label = Label.new()

	game_over_label.position = Vector2(
		screen_size.x / 2.0 - 170.0,
		screen_size.y / 2.0 - 70.0
	)

	game_over_label.text = "GAME OVER"

	game_over_label.add_theme_font_size_override(
		"font_size",
		32
	)

	game_over_label.visible = false

	add_child(game_over_label)


# =========================================================
# UPDATE SCORE
# =========================================================

func update_score() -> void:

	score_label.text = "SCORE: " + str(score)


# =========================================================
# GAME OVER
# =========================================================

func show_game_over() -> void:

	game_over_label.text = "GAME OVER\n\nSCORE: " + str(score) + "\n\nTekan ENTER untuk ulang"

	game_over_label.visible = true


# =========================================================
# RESTART GAME
# =========================================================

func restart_game() -> void:

	meteors.clear()

	score = 0

	meteor_timer = 0.0

	game_over = false


	player_pos = Vector2(
		screen_size.x / 2.0,
		screen_size.y - 80.0
	)


	update_score()

	game_over_label.visible = false

	create_stars()

	queue_redraw()
